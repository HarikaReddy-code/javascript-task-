var entry=document.getElementById("entry");
entry.addEventListener("click",displayDetails);
var row = 1;

function displayDetails(){
  var User id = document.getElementById("id").value;
  var User name = document.getElementById("name").value;
  var Email = document.getElementById("email").value;

if (!User id || !User name || !Email) {
  alert("Please fill all the boxes");
  return;
  }

  var display=document.getElementById("display");
  var newRow= display.insertRow(row);
  var cell1 = newRow.insertcell(0);
  var cell2 = newRow.insertcell(1);
  var cell3 = newRow.insertcell(2);

  cell1.innerHTML =  User id;
  cell2.innerHTML = User name;
  cell3.innerHTML = Email;
  row++;
}
